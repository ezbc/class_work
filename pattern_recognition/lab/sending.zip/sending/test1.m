% clear all;
close all;

load feature_hough





i=19;



%^%%%%%%%%%%%%%%%%%%%%%% CHANGE I%%%%%%%%%%%%%%%%%%%%%%
HE_IMAGE='images\TransformedTumour Pancreas 84-1.tif';
SHG_IMAGE='images\pancreatic tumor 2000 - 84-1.tif';
% HE_IMAGE='G3 #145 tumor pancreas.tif';
% SHG_IMAGE='SHGresized.tif';



[feature(i).A,feature(i).H_subimage,feature(i).H_block]=hough_feature_generator(HE_IMAGE,SHG_IMAGE,50);

% test_feature=hough_feature_generator(HE_IMAGE,SHG_IMAGE,50);


